
        localStorage.clear();
        sessionStorage.clear();
    
