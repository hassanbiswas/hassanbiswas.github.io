# Web Developer | Hassan Biswas
Professional Website Designer & Front-end Developer

## Contact
    Portfolio :      hassanbiswas.github.io
    Gmail     :      hassanbiswas.github.io@gmail.com
    Messenger : m.me/hassanbiswas.github.io
    
    Whatsapp  : wa.me/8801602873384

## Follow
    Facebook  : facebook.com/hassanbiswas.github.io
    Instagram : instagram.com/hassanbiswas.github.io

    
# App

## Overview
This app allows user & client to stay connected with Web developer | Hassan Biswas.

## Features
- Easier connection & access
- Multiple browser support
- Multiple devices support
- User friendly UI
- 24/7 support

## Installation
1. download the app from URL
or
2. visit https://hassanbiswas.github.io & from your browsers > menu > cast,save,share > install page as app.

## Usage:
    - Install & open the app
    - Browse products
    - Choose product
    - Contact me
    - Buy product

## Acknowledgements:
    All over the World



