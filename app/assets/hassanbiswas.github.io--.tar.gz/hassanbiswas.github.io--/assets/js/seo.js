// seo script goes here!

console.log('hello world');